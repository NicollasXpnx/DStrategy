public interface ICalcMedia {

    double CalculaMedia(double P1, double P2);
    String Situacao(double media);

}
